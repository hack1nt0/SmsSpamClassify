package com.xiaomi.smsspam.preprocess;

import com.xiaomi.smsspam.Corpus;
import com.xiaomi.smsspam.MainClass;
import com.xiaomi.smsspam.Options;
import com.xiaomi.smsspam.Segment;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by dy on 14-10-22.
 */
public class Word extends RulePrevious{

    private static Map<String, Integer> glossary;

    public static Map<String, Integer> getGlossary() {
        return glossary;
    }

/*
    class Segment {

        static
        {
            //System.loadLibrary("segment");
            System.loadLibrary("segment_migp_hmm");
            //System.loadLibrary("segment_hmmonly");
        }
        private long mNativeObj = 0;

        public void init(){
            MainClass.log("Start");
            System.out.println("init start");
            mNativeObj = nativeInitObject();
            System.out.println("init end. value:" + mNativeObj);
            MainClass.log("Init");
        }

        public void destroy(){
            nativeDestroyObject(mNativeObj);
            mNativeObj = 0;
        }

        public String[] cut(String res){
            return nativeCut(mNativeObj, res);
        }

        public boolean inDict(String str){
            if(str.length() <= 0){
                return false;
            }
            return nativeInDict(mNativeObj, str);
        }

        private static native long nativeInitObject();

        private static native void nativeDestroyObject(long thiz);

        private static native String[] nativeCut(long thiz, String res);

        private static native boolean nativeInDict(long thiz, String res);
    }*/

    private static Segment tokenizer;

    static{
        tokenizer = new Segment();
        tokenizer.init();
    }

    public static Segment getSeg(){
        return tokenizer;
    }


    @Override
    public boolean doFitting(int[] vals, int start) {
        ArrayList list = new ArrayList(){{
            add("A");
            add("B");
        }};
        return false;
    }

    @Override
    protected List<String> process(String str) {
        List<String> res = new ArrayList<>();
        String[] segs = tokenizer.cut(str);
        for (String seg : segs) {
            if (Options.ONLY_DICT_WORD && !tokenizer.inDict(seg)) continue;
            res.add(seg);
        }
        return res;
    }

    @Override
    public int subClassCount() {
        return glossary.size();
    }

    @Override
    public void train(List<Corpus> cpss) {

    }

    @Override
    public String getName() {
        return "Word";
    }

    @Override
    public void readDef(DataInputStream dataIn) throws IOException {

    }

    @Override
    public void writeDef(DataOutputStream dataOut) throws IOException {

    }
}
